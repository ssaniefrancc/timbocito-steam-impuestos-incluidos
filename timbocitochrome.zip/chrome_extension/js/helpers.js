const attributeName = "data-original-price";

let standardTaxes = [
    {
        name: "IVA Servicios Digitales (Paraguay)",
        value: 10,
        moreInfo: "https://www.set.gov.py/portal/PARAGUAY-SET"
    }
];

let provinceTaxes = [
    {
        name: "Comisiones bancarias o recargos adicionales.",
        value: 0
    }
]

let regionalPricingChartLatam = [
    {
        usdPrice: 0.99,
        argPrice: 0.89
    },
    {
        usdPrice: 1.99,
        argPrice: 1.39
    },
    {
        usdPrice: 2.99,
        argPrice: 2.19
    },
    {
        usdPrice: 3.99,
        argPrice: 2.69
    },
    {
        usdPrice: 4.99,
        argPrice: 3.29
    },
    {
        usdPrice: 5.99,
        argPrice: 3.99
    },
    {
        usdPrice: 6.99,
        argPrice: 4.69
    },
    {
        usdPrice: 7.99,
        argPrice: 4.99
    },
    {
        usdPrice: 8.99,
        argPrice: 5.79
    },
    {
        usdPrice: 9.99,
        argPrice: 6.29
    },
    {
        usdPrice: 10.99,
        argPrice: 6.69
    },
    {
        usdPrice: 11.99,
        argPrice: 6.99
    },
    {
        usdPrice: 12.99,
        argPrice: 7.49
    },
    {
        usdPrice: 13.99,
        argPrice: 8.09
    },
    {
        usdPrice: 14.99,
        argPrice: 8.55
    },
    {
        usdPrice: 15.99,
        argPrice: 9.09
    },
    {
        usdPrice: 16.99,
        argPrice: 9.55
    },
    {
        usdPrice: 17.99,
        argPrice: 9.95
    },
    {
        usdPrice: 18.99,
        argPrice: 10.49
    },
    {
        usdPrice: 19.99,
        argPrice: 10.99
    },
    {
        usdPrice: 24.99,
        argPrice: 12.49
    },
    {
        usdPrice: 29.99,
        argPrice: 14.49
    },
    {
        usdPrice: 34.99,
        argPrice: 16.49
    },
    {
        usdPrice: 39.99,
        argPrice: 18.49
    },
    {
        usdPrice: 44.99,
        argPrice: 20.49
    },
    {
        usdPrice: 49.99,
        argPrice: 22.99
    },
    {
        usdPrice: 54.99,
        argPrice: 25.49
    },
    {
        usdPrice: 59.99,
        argPrice: 28.25
    },
    {
        usdPrice: 64.99,
        argPrice: 29.99
    },
    {
        usdPrice: 69.99,
        argPrice: 31.99
    },
    {
        usdPrice: 74.99,
        argPrice: 34.99
    },
    {
        usdPrice: 79.99,
        argPrice: 36.99
    },
    {
        usdPrice: 84.99,
        argPrice: 38.99
    },
    {
        usdPrice: 89.99,
        argPrice: 39.99
    },
    {
        usdPrice: 99.99,
        argPrice: 45.99
    },
    {
        usdPrice: 109.99,
        argPrice: 50.99
    },
    {
        usdPrice: 119.99,
        argPrice: 54.99
    },
    {
        usdPrice: 129.99,
        argPrice: 59.99
    },
    {
        usdPrice: 139.99,
        argPrice: 64.99
    },

    {
        usdPrice: 149.99,
        argPrice: 68.99
    },
    {
        usdPrice: 199.99,
        argPrice: 89.99
    },
]



let regionalPricingChartLatamPPP = [
    {
        usdPrice: 0.99,
        argPrice: 0.45
    },
    {
        usdPrice: 1.99,
        argPrice: 0.55
    },
    {
        usdPrice: 2.99,
        argPrice: 0.65
    },
    {
        usdPrice: 3.99,
        argPrice: 0.85
    },
    {
        usdPrice: 4.99,
        argPrice: 1.09
    },
    {
        usdPrice: 5.99,
        argPrice: 1.29
    },
    {
        usdPrice: 6.99,
        argPrice: 1.55
    },
    {
        usdPrice: 7.99,
        argPrice: 1.75
    },
    {
        usdPrice: 8.99,
        argPrice: 1.99
    },
    {
        usdPrice: 9.99,
        argPrice: 2.19
    },
    {
        usdPrice: 10.99,
        argPrice: 2.39
    },
    {
        usdPrice: 11.99,
        argPrice: 2.65
    },
    {
        usdPrice: 12.99,
        argPrice: 2.85
    },
    {
        usdPrice: 13.99,
        argPrice: 3.09
    },
    {
        usdPrice: 14.99,
        argPrice: 3.29
    },
    {
        usdPrice: 15.99,
        argPrice: 3.49
    },
    {
        usdPrice: 16.99,
        argPrice: 3.75
    },
    {
        usdPrice: 17.99,
        argPrice: 3.95
    },
    {
        usdPrice: 18.99,
        argPrice: 4.19
    },
    {
        usdPrice: 19.99,
        argPrice: 4.39
    },
    {
        usdPrice: 24.99,
        argPrice: 5.49
    },
    {
        usdPrice: 29.99,
        argPrice: 6.59
    },
    {
        usdPrice: 34.99,
        argPrice: 7.69
    },
    {
        usdPrice: 39.99,
        argPrice: 8.79
    },
    {
        usdPrice: 44.99,
        argPrice: 9.89
    },
    {
        usdPrice: 49.99,
        argPrice: 10.99
    },
    {
        usdPrice: 54.99,
        argPrice: 11.99
    },
    {
        usdPrice: 59.99,
        argPrice: 13.25
    },
    {
        usdPrice: 64.99,
        argPrice: 14.25
    },
    {
        usdPrice: 69.99,
        argPrice: 15.49
    },
    {
        usdPrice: 74.99,
        argPrice: 16.49
    },
    {
        usdPrice: 79.99,
        argPrice: 17.49
    },
    {
        usdPrice: 84.99,
        argPrice: 18.75
    },
    {
        usdPrice: 89.99,
        argPrice: 19.75
    },
    {
        usdPrice: 99.99,
        argPrice: 21.99
    },
    {
        usdPrice: 109.99,
        argPrice: 24.25
    },
    {
        usdPrice: 119.99,
        argPrice: 26.49
    },
    {
        usdPrice: 129.99,
        argPrice: 28.49
    },
    {
        usdPrice: 139.99,
        argPrice: 30.75
    },

    {
        usdPrice: 149.99,
        argPrice: 32.99
    },
    {
        usdPrice: 199.99,
        argPrice: 43.99
    },
]


const regionalPricingOptionsLatam = regionalPricingChartLatam.map(item => item.usdPrice)



function setProvinceTax() {
    if (localStorage.hasOwnProperty('timbocito-province-tax')) {
        let taxValue = localStorage.getItem('timbocito-province-tax');

        if (taxValue == 0) {
            return [{
                name: "No se seleccionaron impuestos adicionales.",
                value: taxValue
            }]
        }

        return [{
            name: "Recargo bancario personalizado",
            value: taxValue
        }]
    }

    return provinceTaxes;
}

function setNationalTax() {

    if (localStorage.hasOwnProperty('timbocito-national-tax')) {
        let taxValue = localStorage.getItem('timbocito-national-tax');

        standardTaxes = [{
            name: "Impuestos Nacionales personalizados por vos",
            value: taxValue
        }];
    }

    // Si no existen custom taxes nacionales en localStorage, agarrar taxes oficiales
    return standardTaxes;
}

let taxes = setNationalTax();
provinceTaxes = setProvinceTax();

const priceContainers = `
        .discount_original_price:not([${attributeName}]), 
        .discount_final_price:not([${attributeName}]), 
        .game_purchase_price:not([${attributeName}]), 
        [class*=salepreviewwidgets_StoreSalePriceBox]:not([${attributeName}]), 
        [class*=salepreviewwidgets_StoreOrignalPrice]:not([${attributeName}]), 
        [class*=salepreviewwidgets_StoreOriginalPrice]:not([${attributeName}]), 
        .search_price:not([${attributeName}]), 
        .regular_price:not([${attributeName}]), 
        .match_price:not([${attributeName}]), 
        .cart_item .price:not([${attributeName}]),
        .price.bundle_final_package_price:not([${attributeName}]),
        .price.bundle_final_price_with_discount:not([${attributeName}]),
        .bundle_savings:not([${attributeName}]),
        .package_info_block_content .price:not([${attributeName}]),
        #package_savings_bar .savings:not([${attributeName}]),
        .promo_item_list .price span:not([${attributeName}]),
        .apphub_StorePrice .price:not([${attributeName}]),
        .item_def_price:not([${attributeName}]),
        .match_subtitle:not([${attributeName}]),
        .regional-meter-price:not([${attributeName}]),
        .StoreSalePriceWidgetContainer.Discounted >div >div:not([${attributeName}]),
        .StoreSalePriceWidgetContainer:not(.Discounted) >div:not([${attributeName}]),
        .AppCapsuleCtn >span >span:not([${attributeName}])
        `;

function getTotalTaxes() {
    function reducer(total, num) {
        return total + num;
    }
    let taxesValues = taxes.map(tax => tax.value);
    let provinceTaxesValues = provinceTaxes.map(tax => tax.value);
    let totalTaxes = (1 + (taxesValues.reduce(reducer) / 100) + (provinceTaxesValues.reduce(reducer) / 100));

    return totalTaxes;
}

function calcularImpuestos(initialPrice) {
    let finalPrice = initialPrice;


    provinceTaxes &&
        provinceTaxes.forEach(tax => {
            finalPrice += parseFloat((initialPrice * tax.value / 100).toFixed(2));
        })

    return finalPrice.toFixed(2);
}

 function calculateTaxesAndExchange(initialPrice,exchangeRate = "unset") {

    if(exchangeRate=="unset"){
        let cotizacion = JSON.parse(localStorage.getItem('timbocito-cotizacion-tarjeta'));
        exchangeRate = cotizacion ? cotizacion.rate : 6100;
    }

    let arsPriceBeforeTaxes = initialPrice * exchangeRate
    let finalPrice = initialPrice * exchangeRate;

    taxes &&
        taxes.forEach(tax => {
            finalPrice += parseFloat((arsPriceBeforeTaxes * tax.value / 100).toFixed(2));
        })

    provinceTaxes &&
        provinceTaxes.forEach(tax => {
            finalPrice += parseFloat((arsPriceBeforeTaxes * tax.value / 100).toFixed(2));
        })

    return finalPrice.toFixed(2);
}

function getBalance() {
    let walletBalanceContainer = document.querySelector("#header_wallet_balance");

    // fallback por xpath para cuando no se encuentra el contenedor de saldo (por ejemplo, en la wishlist)
    if (!walletBalanceContainer) {
        const xpath =
            "//a[(starts-with(text(), 'Cartera') or starts-with(text(), 'Wallet')) and contains(@href, 'store.steampowered.com/account')]/b";
        const result = document.evaluate(
            xpath,
            document,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
        );
        walletBalanceContainer = result.singleNodeValue;
    }
    
    if (localStorage.getItem('manual-mode') == "wallet") {
        return 9999999;
    } else if (localStorage.getItem('manual-mode') == "mate") {
        return 0;
    }
    else if (walletBalanceContainer) {
        walletBalanceContainer.innerHTML += emojiWallet;
        // Fix para resolver problema de detección de saldo cuando tenés un reembolso pendiente
        let walletBalance = document.createElement('p');
        walletBalance.innerText = walletBalanceContainer.innerText;
        if(walletBalance.innerText.includes('Pend')){
            walletBalance.innerText = walletBalance.innerText.slice(0, walletBalance.innerText.indexOf('Pend'))
        }
        // return 6.12;
        return stringToNumber(walletBalance);
    }
    return 0;
}

function extractNumberFromString(string){
    let match = string.match(/[\d,.]+/);
    if(match){
        let numStr = match[0];
        
        // Si tiene coma y punto, el último es el separador decimal
        if (numStr.includes(',') && numStr.includes('.')) {
            if (numStr.lastIndexOf(',') > numStr.lastIndexOf('.')) {
                // Formato: 1.234,56
                numStr = numStr.replace(/\./g, '').replace(',', '.');
            } else {
                // Formato: 1,234.56
                numStr = numStr.replace(/,/g, '');
            }
        } else if (numStr.includes(',')) {
            // Solo tiene coma. Si termina en 2 dígitos, es decimal (ej. 21,99)
            let parts = numStr.split(',');
            if (parts.length > 1 && parts[parts.length - 1].length === 2) {
                numStr = numStr.replace(',', '.');
            } else {
                numStr = numStr.replace(/,/g, ''); // Separador de miles
            }
        }
        
        return numStr;
    }
}

function stringToNumber(number, positionArs = 5) {
    if(!number.innerText.includes('ARS')){
        return extractNumberFromString(number.innerText);
    }

    // Comprobación para cuando a Steam le pinta cambiar el orden de las comas y decimales!
    const numero = number.innerText;
    if (numero) {
        if (numero.indexOf(',') != -1 && numero.indexOf('.') != -1) {
            if (numero.indexOf(',') < numero.indexOf('.')) {
                const numeroArreglado = numero.replace(',', '')
                return parseFloat(numeroArreglado.slice(positionArs));
            }
        }
    }

    if (numero) {
        if (numero.indexOf(',') == -1) {
            const numeroArreglado = numero;
            return parseFloat(numeroArreglado.slice(positionArs));
        }
    }


    if (positionArs != "none") {
        return parseFloat(number.innerText.slice(positionArs).replace(".", "").replace(",", "."));
    } else {
        return parseFloat(number.replace(".", "").replace(",", "."));
    }
}

function stringToNumber2(number, positionArs = 5) {
    return parseFloat(number.slice(positionArs).replace(".", "").replace(",", "."));
}

function numberToString(number, keepDecimals = true) {
    if (number !== undefined && number !== null) {
        // parseFloat por si llega como string desde dataset
        let roundedNumber = Math.round(parseFloat(number));
        let parts = roundedNumber.toString().split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        return '₲ ' + parts[0]; // En Paraguay no se suelen usar decimales para Guaraníes
    }
}

function numberToStringUsd(number) {
    if (number) {
        let parts = number.toString().split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        return 'USD$ ' + parts.join(",");
    }
}

function numberToStringSub(number) {
    return `${number}`.replace('.', ',');
}

function isInsideString(element, string) {
    return element.innerText.indexOf(string) != -1 ? true : false;
}

function guaranizar(contenedor, emoji = true) {
    let emojiStatus = emoji ? emojiMate : "";
    return numberToString(contenedor) + emojiStatus;
}

function steamizar(contenedor, emoji = true) {
    let emojiStatus = emoji ? emojiWallet : "";
    return numberToStringUsd(contenedor) + emojiStatus;
}



const currentChange = "patch"; // patch | minor | major

function showUpdate() {
    chrome.storage.local.get(['justUpdated'], function (result) {

        // Si es la primera vez que se abre desde la actualización
        if (result.justUpdated == 1 && currentChange == "major") {
            let header = document.querySelector('#global_header');
            let changelogUrl = 'https://github.com/ssaniefrancc/timbocito-steam-impuestos-incluidos/releases'
            let newVersion = chrome.runtime.getManifest().version;

            let updateAdvice = `
                <div class="actualizacion-timbocito">
                    <p>${emojiMate} ¡timbocito se actualizó correctamente a la versión ${newVersion}! 
                        <a href="${changelogUrl}" target="_blank">¿Qué hay de nuevo?</a>
                    </p> 
                </div>
            `;

            header.insertAdjacentHTML('afterend', updateAdvice);
            chrome.storage.local.set({ justUpdated: 0 });
        }
    });
}
